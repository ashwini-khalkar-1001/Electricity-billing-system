package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class View_Information extends JFrame implements ActionListener
{
    String view;
    JButton cancel;
    View_Information(String view)
    {
        super("View Information");

        this.view=view;
        //getContentPane().setBackground(Color.WHITE);

        setBounds(300,40,850,650);
        setLayout(null);

        JLabel heading=new JLabel("View Customer Information");
        heading.setBounds(250,0,400,40);
        heading.setFont(new Font("serif",Font.BOLD,30));
        add(heading);

        JLabel nameLable=new JLabel("Name");
        nameLable.setBounds(70,80,100,30);
        add(nameLable);
        JLabel nameLableText=new JLabel("");
        nameLableText.setBounds(200,80,150,30);
        add(nameLableText);

        JLabel meterno=new JLabel("Meter Number");
        meterno.setBounds(70,130,100,30);
        add(meterno);
        JLabel meternoText=new JLabel("");
        meternoText.setBounds(200,130,150,30);
        add(meternoText);

        JLabel address=new JLabel("Address");
        address.setBounds(70,180,100,30);
        add(address);
        JLabel addressText=new JLabel("");
        addressText.setBounds(200,180,150,30);
        add(addressText);

        JLabel city=new JLabel("City ");
        city.setBounds(70,230,100,30);
        add(city);
        JLabel cityText=new JLabel("");
        cityText.setBounds(200,230,150,30);
        add(cityText);

        JLabel state=new JLabel("State ");
        state.setBounds(500,80,100,30);
        add(state);
        JLabel stateText=new JLabel("");
        stateText.setBounds(600,80,150,30);
        add(stateText);

        JLabel email=new JLabel("Email ");
        email.setBounds(500,130,100,30);
        add(email);
        JLabel emailText=new JLabel("");
        emailText.setBounds(600,130,150,30);
        add(emailText);

        JLabel phone=new JLabel("Phone ");
        phone.setBounds(500,180,100,30);
        add(phone);
        JLabel phoneText=new JLabel("");
        phoneText.setBounds(600,180,150,30);
        add(phoneText);


        try
        {
            Database c=new Database();
            ResultSet resultSet=c.statement.executeQuery("select * from new_customer where meter_no='"+view+"'");
            if (resultSet.next())
            {
                nameLableText.setText(resultSet.getString("name"));
                meternoText.setText(resultSet.getString("meter_no"));
                addressText.setText(resultSet.getString("address"));
                cityText.setText(resultSet.getString("city"));
                stateText.setText(resultSet.getString("state"));
                emailText.setText(resultSet.getString("email"));
                phoneText.setText(resultSet.getString("phone_no"));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        cancel=new JButton("Cancel");
        cancel.setBackground(new Color(70, 114, 182));
        cancel.setForeground(Color.WHITE);
        cancel.addActionListener(this);
        cancel.setBounds(70,300,100,30);
        add(cancel);

        ImageIcon a1=new ImageIcon(ClassLoader.getSystemResource("Icon/viewinfopage.jpg"));
        Image a2=a1.getImage().getScaledInstance(850,250,Image.SCALE_DEFAULT);
        ImageIcon a3=new ImageIcon(a2);
        JLabel a4=new JLabel(a3);
        a4.setBounds(0,370,850,250);
        add(a4);

        setVisible(true);

    }


    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==cancel)
        {
            setVisible(false);
        }

    }

    public static void main(String[] args)
    {
        new View_Information("");
    }
}
