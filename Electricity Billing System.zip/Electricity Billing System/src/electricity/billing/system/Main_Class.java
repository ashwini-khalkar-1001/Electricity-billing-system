package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main_Class extends JFrame implements ActionListener
{
    String acctype;
    String meter_pass;
    Main_Class(String acctype,String meter_pass)
    {
        super("Electricity Billing System");

        this.meter_pass=meter_pass;
        this.acctype=acctype;
        getContentPane().setBackground(new Color(103, 79, 113));
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        ImageIcon img1=new ImageIcon(ClassLoader.getSystemResource("Icon/main_page.png"));
        Image img2= img1.getImage().getScaledInstance(1430,716,Image.SCALE_DEFAULT);
        ImageIcon img3=new ImageIcon(img2);
        JLabel img4=new JLabel(img3);
        add(img4);

        JMenuBar menuBar=new JMenuBar();
        setJMenuBar(menuBar);

        JMenu menu=new JMenu("Menu");
        menu.setFont(new Font("serif",Font.PLAIN,24));


        JMenuItem newcustomer=new JMenuItem("New Customer");
        newcustomer.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon customerimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/newcustomer.png"));
        Image customerimg2=customerimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        newcustomer.setIcon(new ImageIcon(customerimg2));
        newcustomer.addActionListener(this);
        menu.add(newcustomer);

        JMenuItem customerdetails=new JMenuItem("Customer Details");
        customerdetails.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon customerdetailimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/customerdetails.png"));
        Image customerdetailimg2=customerdetailimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        customerdetails.setIcon(new ImageIcon(customerdetailimg2));
        customerdetails.addActionListener(this);
        menu.add(customerdetails);

        JMenuItem depositdetails=new JMenuItem("Deposit Details");
        depositdetails.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon depositdetailimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/depositdetails.png"));
        Image depositdetailimg2=depositdetailimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        depositdetails.setIcon(new ImageIcon(depositdetailimg2));
        depositdetails.addActionListener(this);
        menu.add(depositdetails);

        JMenuItem calculatebill=new JMenuItem("Calculate Bill");
        calculatebill.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon calculatebillimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/calculatebill.png"));
        Image calculatebillimg2=calculatebillimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        calculatebill.setIcon(new ImageIcon(calculatebillimg2));
        calculatebill.addActionListener(this);
        menu.add(calculatebill);

        JMenu info=new JMenu("Information");
        info.setFont(new Font("serif",Font.PLAIN,24));

        JMenuItem updateinfo=new JMenuItem("Update Information");
        updateinfo.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon updateinfoimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/updateinfo.png"));
        Image updateinfoimg2=updateinfoimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        updateinfo.setIcon(new ImageIcon(updateinfoimg2));
        updateinfo.addActionListener(this);
        info.add(updateinfo);

        JMenuItem viewinfo=new JMenuItem("View Information");
        viewinfo.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon viewinfoimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/viewinfo.png"));
        Image viewinfoimg2=viewinfoimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        viewinfo.setIcon(new ImageIcon(viewinfoimg2));
        viewinfo.addActionListener(this);
        info.add(viewinfo);

        JMenu user=new JMenu("User");
        user.setFont(new Font("serif",Font.PLAIN,24));

        JMenuItem paybill=new JMenuItem("Pay Bill");
        paybill.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon paybillimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/paybill.png"));
        Image paybillimg2=paybillimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        paybill.setIcon(new ImageIcon(paybillimg2));
        paybill.addActionListener(this);
        user.add(paybill);

        JMenuItem billdetails=new JMenuItem("Bill Details");
        billdetails.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon billdetailsimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/billdetails.png"));
        Image billdetailsimg2=billdetailsimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        billdetails.setIcon(new ImageIcon(billdetailsimg2));
        billdetails.addActionListener(this);
        user.add(billdetails);

        JMenu bill=new JMenu("Bill");
        bill.setFont(new Font("serif",Font.PLAIN,24));

        JMenuItem generatebill=new JMenuItem("Generate Bill");
        generatebill.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon generatebillimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/generatebill.jpg"));
        Image generatebillimg2=generatebillimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        generatebill.setIcon(new ImageIcon(generatebillimg2));
        generatebill.addActionListener(this);
        bill.add(generatebill);

        JMenu utility=new JMenu("Utility");
        utility.setFont(new Font("serif",Font.PLAIN,24));

        JMenuItem notepad=new JMenuItem("Notepad");
        notepad.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon notepadimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/notepad.png"));
        Image notepadimg2=notepadimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        notepad.setIcon(new ImageIcon(notepadimg2));
        notepad.addActionListener(this);
        utility.add(notepad);

        JMenuItem calculator=new JMenuItem("Calculator");
        calculator.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon calculatorimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/calculator.png"));
        Image calculatorimg2=calculatorimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        calculator.setIcon(new ImageIcon(calculatorimg2));
        calculator.addActionListener(this);
        utility.add(calculator);

        JMenu exit=new JMenu("Exit");
        exit.setFont(new Font("serif",Font.PLAIN,24));

        JMenuItem exitt=new JMenuItem("Exit");
        exitt.setFont(new Font("monospaced",Font.PLAIN,18));
        ImageIcon exitimg1=new ImageIcon(ClassLoader.getSystemResource("Icon/exit.png"));
        Image exitimg2=exitimg1.getImage().getScaledInstance(22,22,Image.SCALE_DEFAULT);
        exitt.setIcon(new ImageIcon(exitimg2));
        exitt.addActionListener(this);
        exit.add(exitt);



        if (acctype.equals("Admin"))
        {
            menuBar.add(menu);

        }
        else {
            menuBar.add(bill);
            menuBar.add(user);
            menuBar.add(info);


        }
        menuBar.add(utility);
        menuBar.add(exit);





        setLayout(new FlowLayout());
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        String msg=e.getActionCommand();
        if (msg.equals("New Customer"))
        {
            new NewCustomer();
        } else if (msg.equals("Customer Details"))
        {
            new Customer_Details();

        } else if (msg.equals("Deposit Details"))
        {
            new Deposite_Details();
        } else if (msg.equals("Calculate Bill"))
        {
            new Calculate_Bill();

        } else if (msg.equals("Update Information"))
        {
            new Update_Information(meter_pass);


        } else if (msg.equals("View Information"))
        {
            new View_Information(meter_pass);
        } else if (msg.equals("Pay Bill"))
        {

            new Pay_Bill(meter_pass);

        }
        else if (msg.equals("Bill Details"))
        {

            new Bill_Details(meter_pass);
        }
        else if (msg.equals("Generate Bill"))
        {

            new Generate_Bill(meter_pass);

        } else if (msg.equals("Notepad"))
        {
            try
            {
             Runtime.getRuntime().exec("notepad.exe");


            } catch (Exception ex) {
                ex.printStackTrace();
            }

        } else if (msg.equals("Calculator"))
        {

            try
            {
                Runtime.getRuntime().exec("calc.exe");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (msg.equals("Exit"))
        {
        setVisible(false);
        new Login();

        }


    }

    public static void main(String[] args)
    {
        new Main_Class("","");
    }
}
