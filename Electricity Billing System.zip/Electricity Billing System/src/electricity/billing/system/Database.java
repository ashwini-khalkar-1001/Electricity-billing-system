package electricity.billing.system;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.*;

public class Database
{
    Connection connection;
    Statement statement;
    Database()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bill_system", "root", "root123");
            statement=connection.createStatement();
        }catch (Exception e)
        {
            e.printStackTrace();

        }
    }
}
