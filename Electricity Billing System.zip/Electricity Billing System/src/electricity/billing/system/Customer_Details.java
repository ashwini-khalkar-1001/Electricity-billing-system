package electricity.billing.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Customer_Details extends JFrame implements ActionListener
{
    Choice searchmeterCho,searchnameCho;
    JTable table;
    JButton search,print,close;
    Customer_Details()
    {
        super("Customer Details");
        getContentPane().setBackground(new Color(133, 155, 202));

        JLabel searchmeter=new JLabel("Search By Meter Number");
        searchmeter.setBounds(50,30,150,30);
        add(searchmeter);
        searchmeterCho=new Choice();
        searchmeterCho.setBounds(210,30,150,30);
        add(searchmeterCho);
        try
        {
            Database c=new Database();
            ResultSet resultSet=c.statement.executeQuery("select * from new_customer");
            while (resultSet.next())
            {
                searchmeterCho.add(resultSet.getString("meter_no"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        JLabel searchname=new JLabel("Search By Name");
        searchname.setBounds(400,30,150,30);
        add(searchname);
        searchnameCho=new Choice();
        searchnameCho.setBounds(560,30,150,30);
        add(searchnameCho);
        try
        {
            Database c=new Database();
            ResultSet resultSet=c.statement.executeQuery("select * from new_customer");
            while (resultSet.next())
            {
                searchnameCho.add(resultSet.getString("name"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        table=new JTable();
        try
        {
            Database c=new Database();
            ResultSet resultSet=c.statement.executeQuery("select * from new_customer");
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane scrollPane=new JScrollPane(table);
        scrollPane.setBounds(10,130,710,370);
        scrollPane.setBackground(Color.WHITE);
        add(scrollPane);

        search=new JButton("Search");
        search.setBounds(50,80,100,30);
        search.setBackground(Color.WHITE);
        search.addActionListener(this);
        add(search);

        print=new JButton("Print");
        print.setBounds(160,80,100,30);
        print.setBackground(Color.WHITE);
        print.addActionListener(this);
        add(print);

        close=new JButton("Close");
        close.setBounds(600,80,100,30);
        close.setBackground(Color.WHITE);
        close.addActionListener(this);
        add(close);

        setSize(750,550);
        setLocation(300,100);
        setLayout(null);
        setVisible(true);



    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==search)
        {
            String query_search="select * from new_customer where meter_no='"+searchmeterCho.getSelectedItem()+"' and name='"+searchnameCho.getSelectedItem()+"'";
            try
            {
                Database c=new Database();
                ResultSet resultSet=c.statement.executeQuery(query_search);
                table.setModel(DbUtils.resultSetToTableModel(resultSet));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        else if (e.getSource()==print)
        {
            try
            {
                table.print();

            } catch (Exception ex)
            {
                ex.printStackTrace();
            }
        }
        else
        {
            setVisible(false);
        }

    }


    public static void main(String[] args)
    {
      new Customer_Details();
    }
}
