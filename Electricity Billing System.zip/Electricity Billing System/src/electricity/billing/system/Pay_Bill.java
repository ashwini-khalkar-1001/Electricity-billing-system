package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;

public class Pay_Bill extends JFrame implements ActionListener
{
    String meter;
    Choice searchmonthCho;
    JButton pay,back;
    JLabel unitText,totalBillText,statusText;
    Pay_Bill(String meter)
    {
        super("Pay Bill");
        this.meter=meter;
        setSize(900,600);
        setLocation(250,100);
        setLayout(null);

        JLabel heading=new JLabel("Pay Bill");
        heading.setBounds(120,10,400,40);
        heading.setFont(new Font("Tahoma",Font.BOLD,30));
        add(heading);

        JLabel meterno=new JLabel("Meter Number");
        meterno.setBounds(35,80,200,30);
        add(meterno);
        JLabel meternoText=new JLabel("");
        meternoText.setBounds(300,80,200,30);
        add(meternoText);

        JLabel name=new JLabel("Name");
        name.setBounds(35,130,200,30);
        add(name);
        JLabel nameText=new JLabel("");
        nameText.setBounds(300,130,200,30);
        add(nameText);

        JLabel month=new JLabel("Month");
        month.setBounds(35,180,200,30);
        add(month);
        searchmonthCho=new Choice();
        searchmonthCho.add("January");
        searchmonthCho.add("February");
        searchmonthCho.add("March");
        searchmonthCho.add("April");
        searchmonthCho.add("May");
        searchmonthCho.add("June");
        searchmonthCho.add("July");
        searchmonthCho.add("August");
        searchmonthCho.add("September");
        searchmonthCho.add("October");
        searchmonthCho.add("November");
        searchmonthCho.add("December");
        searchmonthCho.setBounds(300,180,200,30);
        add(searchmonthCho);

        JLabel unit=new JLabel("Unit");
        unit.setBounds(35,230,200,30);
        add(unit);
         unitText=new JLabel("");
        unitText.setBounds(300,230,200,30);
        add(unitText);

        JLabel totalBill=new JLabel("Total Bill");
        totalBill.setBounds(35,280,200,30);
        add(totalBill);
        totalBillText=new JLabel("");
        totalBillText.setBounds(300,280,200,30);
        add(totalBillText);

        JLabel status=new JLabel("Status");
        status.setBounds(35,330,200,30);
        add(status);
         statusText=new JLabel("");
        statusText.setBounds(300,330,200,30);
        statusText.setForeground(Color.RED);
        add(statusText);


        try
        {
            Database c=new Database();
            ResultSet resultSet=c.statement.executeQuery("select * from new_customer where meter_no='"+meter+"'");
            while (resultSet.next())
            {
                meternoText.setText(meter);
                nameText.setText(resultSet.getString("name"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        searchmonthCho.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {



                try
                {
                    Database c=new Database();
                    ResultSet resultSet=c.statement.executeQuery("select * from bill where meter_no='"+meter+"' and month='"+searchmonthCho.getSelectedItem()+"'");
                    while (resultSet.next()) {
                        unitText.setText(resultSet.getString("unit"));
                        totalBillText.setText(resultSet.getString("total_bill"));
                        statusText.setText(resultSet.getString("status"));
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        });

        pay=new JButton("Pay");
        pay.setBounds(100,400,120,30);
        pay.setBackground(new Color(10, 67, 89));
        pay.setForeground(Color.WHITE);
        pay.addActionListener(this);
        add(pay);

        back=new JButton("Back");
        back.setBounds(300,400,120,30);
        back.setBackground(new Color(10, 67, 89));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);


        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {

        if (e.getSource()==pay)
        {
            try
            {
                Database c=new Database();
                c.statement.executeUpdate("update bill set status='paid' where meter_no='"+meter+"' and month='"+searchmonthCho.getSelectedItem()+"'");

            } catch (Exception ex) {
                ex.printStackTrace();
            }
            setVisible(false);
            new Payment_Bill(meter);
        }else
        {
            setVisible(false);
        }
    }

    public static void main(String[] args) {
        new Pay_Bill("");
    }
}
