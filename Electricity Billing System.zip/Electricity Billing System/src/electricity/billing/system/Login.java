package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Login extends JFrame implements ActionListener
{
    JTextField usertext,passwordtext,logintext;
    Choice loginchoice;
    JButton logginbutton,cancelbutton,signupbutton;
    Login()
    {
        super("login");
        getContentPane().setBackground(new Color(156, 209, 202));

        JLabel usename=new JLabel("UserName :");
        usename.setBounds(300,60,100,30);
        add(usename);
        usertext=new JTextField();
        usertext.setBounds(400,60,150,30);
        add(usertext);

        JLabel password=new JLabel("Password :");
        password.setBounds(300,100,100,30);
        add(password);
        passwordtext=new JTextField();
        passwordtext.setBounds(400,100,150,30);
        add(passwordtext);

        JLabel loggin=new JLabel("Login In As :");
        loggin.setBounds(300,140,100,30);
        add(loggin);
        loginchoice=new Choice();
        loginchoice.add("Admin");
        loginchoice.add("Customer");
        loginchoice.setBounds(400,140,150,30);
        add(loginchoice);

        logginbutton=new JButton("Login");
        logginbutton.setBounds(320,190,100,30);
        logginbutton.addActionListener(this);
        add(logginbutton);

        cancelbutton=new JButton("Cancel");
        cancelbutton.setBounds(440,190,100,30);
        cancelbutton.addActionListener(this);
        add(cancelbutton);

        signupbutton=new JButton("Sign Up");
        signupbutton.setBounds(380,230,100,30);
        signupbutton.addActionListener(this);
        add(signupbutton);

        ImageIcon loginimg=new ImageIcon(ClassLoader.getSystemResource("Icon/login.jpg"));
        Image loginimg2=loginimg.getImage().getScaledInstance(250,250,Image.SCALE_DEFAULT);
        ImageIcon loginimg3=new ImageIcon(loginimg2);
        JLabel loginimglabel=new JLabel(loginimg3);
        loginimglabel.setBounds(30,30,250,250);
        add(loginimglabel);

        setSize(600,400);
        setLocation(100,100);
        setLayout(null);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==logginbutton)
        {
            String susername=usertext.getText();
            String spassword=passwordtext.getText();
            String suser=loginchoice.getSelectedItem();
            try
            {
                Database c=new Database();
                String Query="select * from signupdata where username='"+susername+"' and password='"+spassword+"' and usertype='"+suser+"'";
                ResultSet resultSet=c.statement.executeQuery(Query);

                if(resultSet.next())
                {
                    String meter=resultSet.getString("meter_no");
                    setVisible(false);
                    new Main_Class(suser,meter);
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"Invalid Login ");
                }
            }
            catch (Exception E)
            {
                E.printStackTrace();
            }

        } else if (e.getSource()==cancelbutton)
        {
            setVisible(false);

        } else if (e.getSource()==signupbutton)
        {
            setVisible(false);
            new Signup();

        }

    }

    public static void main(String[] args)
    {
        new Login();
    }
}
