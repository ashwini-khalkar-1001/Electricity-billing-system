package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class NewCustomer extends JFrame implements ActionListener
{
    JLabel heading,customername,meterno,address,city,state,email,phone,meterText;
    TextField nameText,addressText,cityText,stateText,emailText,phoneText;
    JButton next,cancel;
    NewCustomer()
    {
        super("New Customer");
        setSize(750,550);
        setLocation(300,100);

        JPanel panel=new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(194, 163, 220));
        add(panel);

        heading=new JLabel("New Customer");
        heading.setBounds(190,10,200,30);
        heading.setFont(new Font("Tahoma",Font.BOLD,20));
        panel.add(heading);

        customername=new JLabel("New Customer :");
        customername.setBounds(50,80,100,30);
        panel.add(customername);
        nameText=new TextField();
        nameText.setBounds(180,80,180,30);
        panel.add(nameText);

        meterno=new JLabel("Meter Number :");
        meterno.setBounds(50,120,100,30);
        panel.add(meterno);
        meterText=new JLabel("");
        meterText.setBounds(180,120,180,30);
        panel.add(meterText);
        Random ran=new Random();
        long number=ran.nextLong()%1000000;
        meterText.setText(""+Math.abs(number));

        address=new JLabel("Address:");
        address.setBounds(50,160,100,30);
        panel.add(address);
        addressText=new TextField();
        addressText.setBounds(180,160,180,30);
        panel.add(addressText);

        city=new JLabel("City:");
        city.setBounds(50,200,100,30);
        panel.add(city);
        cityText=new TextField();
        cityText.setBounds(180,200,180,30);
        panel.add(cityText);

        state=new JLabel("State:");
        state.setBounds(50,240,100,30);
        panel.add(state);
        stateText=new TextField();
        stateText.setBounds(180,240,180,30);
        panel.add(stateText);

        email=new JLabel("Email:");
        email.setBounds(50,280,100,30);
        panel.add(email);
        emailText=new TextField();
        emailText.setBounds(180,280,180,30);
        panel.add(emailText);

        phone=new JLabel("Phone:");
        phone.setBounds(50,320,100,30);
        panel.add(phone);
        phoneText=new TextField();
        phoneText.setBounds(180,320,180,30);
        panel.add(phoneText);

        next=new JButton("Next");
        next.setBounds(70,370,125,30);
        next.setBackground(new Color(46, 92, 161));
        next.setForeground(Color.WHITE);
        next.addActionListener(this);
        panel.add(next);

        cancel=new JButton("Cancel");
        cancel.setBounds(230,370,125,30);
        cancel.setBackground(new Color(46, 92, 161));
        cancel.setForeground(Color.WHITE);
        cancel.addActionListener(this);
        panel.add(cancel);

        setLayout(new BorderLayout());
       add(panel,"Center");

       ImageIcon I1=new ImageIcon(ClassLoader.getSystemResource("Icon/customerpage.png"));
       Image I2=I1.getImage().getScaledInstance(220,320,Image.SCALE_DEFAULT);
       ImageIcon I3=new ImageIcon(I2);
       JLabel I4=new JLabel(I3);
       //I4.setBackground(new Color(204, 174, 108));
       //
        // I4.setBounds(40,50,250,300);
       add(I4,"West");


        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==next)
        {
            String sname=nameText.getText();
            String smeter=meterText.getText();
            String saddress=addressText.getText();
            String scity=cityText.getText();
            String sstate=stateText.getText();
            String semail=emailText.getText();
            String sphone=phoneText.getText();

            String query_customer="insert into new_customer values('"+sname+"','"+smeter+"','"+saddress+"','"+scity+"','"+sstate+"','"+semail+"','"+sphone+"')";
            String query_signup="insert into signupdata values('"+smeter+"','','"+sname+"','','')";

            try
            {
                Database c=new Database();
                c.statement.executeUpdate(query_customer);
                c.statement.executeUpdate(query_signup);

                JOptionPane.showMessageDialog(null,"Customer details added successfully");
                setVisible(false);
                new MeterInfo(smeter);

            } catch (Exception E) {
                E.printStackTrace();
            }
        }else
        {
            setVisible(false);
        }

    }

    public static void main(String[] args)
    {
        new NewCustomer();
    }
}
