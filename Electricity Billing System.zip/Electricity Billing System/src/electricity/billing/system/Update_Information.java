package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Update_Information extends JFrame implements ActionListener
{
    String meter;
    JLabel nameText,meterText;
    JTextField addressText,cityText,stateText,emailText,phoneText;
    JButton update,cancel;

    Update_Information(String meter)
    {
        super("Update Information");
        this.meter=meter;

        setBounds(300,100,777,550);
        getContentPane().setBackground(new Color(209, 155, 165));
        setLayout(null);

        JLabel heading=new JLabel("Update Customer Information");
        heading.setBounds(50,10,400,40);
        heading.setFont(new Font("serif",Font.BOLD,30));
        add(heading);

        JLabel name=new JLabel("Name");
        name.setBounds(30,80,100,30);
        add(name);
        nameText=new JLabel("");
        nameText.setBounds(150,80,200,30);
        add(nameText);

        JLabel meterno=new JLabel("Meter Number");
        meterno.setBounds(30,130,100,30);
        add(meterno);
        meterText=new JLabel("");
        meterText.setBounds(150,130,200,30);
        add(meterText);

        JLabel address=new JLabel("Address");
        address.setBounds(30,180,100,30);
        add(address);
        addressText=new JTextField();
        addressText.setBounds(150,180,200,30);
        add(addressText);

        JLabel city=new JLabel("City");
        city.setBounds(30,230,100,30);
        add(city);
        cityText=new JTextField();
        cityText.setBounds(150,230,200,30);
        add(cityText);

        JLabel state=new JLabel("State");
        state.setBounds(30,280,100,30);
        add(state);
        stateText=new JTextField();
        stateText.setBounds(150,280,200,30);
        add(stateText);

        JLabel email=new JLabel("Email");
        email.setBounds(30,330,100,30);
        add(email);
        emailText=new JTextField();
        emailText.setBounds(150,330,200,30);
        add(emailText);

        JLabel phone=new JLabel("Phone");
        phone.setBounds(30,380,100,30);
        add(phone);
        phoneText=new JTextField();
        phoneText.setBounds(150,380,200,30);
        add(phoneText);

        try
        {
            Database c=new Database();
            ResultSet resultSet=c.statement.executeQuery("select * from new_customer where meter_no='"+meter+"'");
            if (resultSet.next())
            {
                nameText.setText(resultSet.getString("name"));
                meterText.setText(resultSet.getString("meter_no"));
                addressText.setText(resultSet.getString("address"));
                cityText.setText(resultSet.getString("city"));
                stateText.setText(resultSet.getString("state"));
                emailText.setText(resultSet.getString("email"));
                phoneText.setText(resultSet.getString("phone_no"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        update=new JButton("Update");
        update.setBounds(30,450,120,30);
        update.setBackground(new Color(18, 65, 112));
        update.setForeground(Color.WHITE);
        update.addActionListener(this);
        add(update);

        cancel=new JButton("Cancel");
        cancel.setBounds(180,450,120,30);
        cancel.setBackground(new Color(18, 65, 112));
        cancel.setForeground(Color.WHITE);
        cancel.addActionListener(this);
        add(cancel);

        ImageIcon b1=new ImageIcon(ClassLoader.getSystemResource("Icon/updateinfopage.png"));
        Image b2=b1.getImage().getScaledInstance(300,310,Image.SCALE_DEFAULT);
        ImageIcon b3=new ImageIcon(b2);
        JLabel b4=new JLabel(b3);
        b4.setBounds(430,100,300,310);
        add(b4);



        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==update)
        {
           String saddress=addressText.getText();
           String scity=cityText.getText();
           String sstate=stateText.getText();
           String semail=emailText.getText();
           String sphone=phoneText.getText();

           try
           {
               Database c=new Database();
               c.statement.executeUpdate("update new_customer set address='"+saddress+"',city='"+scity+"',state='"+sstate+"',email='"+semail+"',phone_no='"+sphone+"' where meter_no='"+meter+"'");

               JOptionPane.showMessageDialog(null,"User Information Updated Successfully");
               setVisible(false);

           } catch (Exception ex) {
               ex.printStackTrace();
           }

        }else
        {
            setVisible(false);
        }

    }

    public static void main(String[] args)
    {
        new Update_Information("");


    }
}
