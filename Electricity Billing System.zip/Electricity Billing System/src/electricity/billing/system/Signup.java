package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Signup extends JFrame implements ActionListener
{
    Choice loginAsCho;
    JTextField meterText,employerText,userText,nameText,passwordText;
    JButton create,back;
    Signup()
    {
        super("SignUp");
        getContentPane().setBackground(new Color(156, 209, 202));

        JLabel createAS=new JLabel("Create Account As:");
        createAS.setBounds(30,50,125,30);
        add(createAS);
        loginAsCho=new Choice();
        loginAsCho.add("Admin");
        loginAsCho.add("Customer");
        loginAsCho.setBounds(170,50,120,30);
        add(loginAsCho);

        JLabel meterNo=new JLabel("Meter Number :");
        meterNo.setBounds(30,90,125,30);
        meterNo.setVisible(false);
        add(meterNo);
        meterText=new JTextField();
        meterText.setBounds(170,90,120,30);
        meterText.setVisible(false);
        add(meterText);

        JLabel employer=new JLabel("Employer ID :");
        employer.setBounds(30,90,125,30);
        employer.setVisible(true);
        add(employer);
        employerText=new JTextField();
        employerText.setBounds(170,90,120,30);
        employerText.setVisible(true);
        add(employerText);

        JLabel userName=new JLabel("User Name :");
        userName.setBounds(30,130,125,30);
        add(userName);
        userText=new JTextField();
        userText.setBounds(170,130,120,30);
        add(userText);

        JLabel name=new JLabel("Name :");
        name.setBounds(30,170,125,30);
        add(name);
        nameText=new JTextField("");
        nameText.setBounds(170,170,120,30);
        add(nameText);

        meterText.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {

            }

            @Override
            public void focusLost(FocusEvent e) {
                try
                {
                    Database c=new Database();
                    ResultSet resultSet=c.statement.executeQuery("select * from signupdata where meter_no='"+meterText.getText()+"'");
                    if (resultSet.next())
                    {
                        nameText.setText(resultSet.getString("name"));
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        });

        JLabel password=new JLabel("Password :");
        password.setBounds(30,210,125,30);
        add(password);
        passwordText=new JTextField();
        passwordText.setBounds(170,210,120,30);
        add(passwordText);

        loginAsCho.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e)
            {
                String user=loginAsCho.getSelectedItem();
                if(user.equals("Customer"))
                {
                    employer.setVisible(false);
                    nameText.setEditable(false);
                    employerText.setVisible(false);
                    meterNo.setVisible(true);
                    meterText.setVisible(true);
                }
                else
                {
                    employer.setVisible(true);
                    employerText.setVisible(true);
                    meterNo.setVisible(false);
                    meterText.setVisible(false);

                }

            }
        });

        create=new JButton("Create");
        create.setBackground(new Color(28, 76, 151));
        create.setForeground(Color.WHITE);
        create.setBounds(30,270,120,30);
        create.addActionListener(this);
        add(create);

        back=new JButton("Back");
        back.setBackground(new Color(28, 76, 151));
        back.setForeground(Color.WHITE);
        back.setBounds(170,270,120,30);
        back.addActionListener(this);
        add(back);

        ImageIcon signup1=new ImageIcon(ClassLoader.getSystemResource("Icon/signup.jpg"));
        Image signup2=signup1.getImage().getScaledInstance(230,230,Image.SCALE_DEFAULT);
        ImageIcon signup3=new ImageIcon(signup2);
        JLabel signup4=new JLabel(signup3);
        signup4.setBounds(320,50,230,230);
        add(signup4);





        setSize(600,400);
        setLocation(100,100);
        setLayout(null);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==create)
        {
            String sloginas=loginAsCho.getSelectedItem();
            String susername=userText.getText();
            String sname=nameText.getText();
            String spassword=passwordText.getText();
            String smeter=meterText.getText();
            try
            {
                Database c=new Database();
                String query=null;

                if (loginAsCho.equals("Admin"))
                {
                    query="insert into signupdata value('"+smeter+"','"+susername+"','"+sname+"','"+spassword+"','"+sloginas+"')";

                }
                else
                {
                    query="update signupdata set username='"+susername+"',password='"+spassword+"',usertype='"+sloginas+"'where meter_no='"+smeter+"'";

                }
                c.statement.executeUpdate(query);
                JOptionPane.showMessageDialog(null,"Account Created");
                //'"+smeter+"','"+susername+"','"+sname+"','"+spassword+"','"+sloginas+"')
                setVisible(false);
                new Login();
            }catch (Exception E)
            {
                E.printStackTrace();
            }

        } else if (e.getSource()==back) {
            setVisible(false);
            new Login();

        }


    }

    public static void main(String[] args)
    {
        new Signup();

    }
}
