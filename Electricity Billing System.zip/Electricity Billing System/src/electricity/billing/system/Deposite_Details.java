package electricity.billing.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Deposite_Details extends JFrame implements ActionListener
{
    Choice searchmeterCho,searchmonthCho;
    JTable table;
    JButton search,print,close;
    Deposite_Details()
    {
        super("Deposite Details");
        getContentPane().setBackground(new Color(133, 155, 202));

        JLabel searchmeter=new JLabel("Search By Meter Number");
        searchmeter.setBounds(50,30,150,30);
        add(searchmeter);
        searchmeterCho=new Choice();
        searchmeterCho.setBounds(210,30,150,30);
        add(searchmeterCho);
        try
        {
            Database c=new Database();
            ResultSet resultSet=c.statement.executeQuery("select * from bill");
            while (resultSet.next())
            {
                searchmeterCho.add(resultSet.getString("meter_no"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        JLabel searchmonth=new JLabel("Search By month");
        searchmonth.setBounds(400,30,150,30);
        add(searchmonth);
        searchmonthCho=new Choice();
        searchmonthCho.add("January");
        searchmonthCho.add("February");
        searchmonthCho.add("March");
        searchmonthCho.add("April");
        searchmonthCho.add("May");
        searchmonthCho.add("June");
        searchmonthCho.add("July");
        searchmonthCho.add("August");
        searchmonthCho.add("September");
        searchmonthCho.add("October");
        searchmonthCho.add("November");
        searchmonthCho.add("December");
        searchmonthCho.setBounds(560,30,150,30);
        add(searchmonthCho);


        table=new JTable();
        try
        {
            Database c=new Database();
            ResultSet resultSet=c.statement.executeQuery("select * from bill");
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        } catch (Exception e) {
            e.printStackTrace();
        }

        JScrollPane scrollPane=new JScrollPane(table);
        scrollPane.setBounds(10,130,710,370);
        scrollPane.setBackground(Color.WHITE);
        add(scrollPane);

        search=new JButton("Search");
        search.setBounds(50,80,100,30);
        search.setBackground(Color.WHITE);
        search.addActionListener(this);
        add(search);

        print=new JButton("Print");
        print.setBounds(160,80,100,30);
        print.setBackground(Color.WHITE);
        print.addActionListener(this);
        add(print);

        close=new JButton("Close");
        close.setBounds(600,80,100,30);
        close.setBackground(Color.WHITE);
        close.addActionListener(this);
        add(close);

        setSize(750,550);
        setLocation(300,100);
        setLayout(null);
        setVisible(true);



    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==search)
        {
            String query_search="select * from bill where meter_no='"+searchmeterCho.getSelectedItem()+"' and month='"+searchmonthCho.getSelectedItem()+"'";
            try
            {
                Database c=new Database();
                ResultSet resultSet=c.statement.executeQuery(query_search);
                table.setModel(DbUtils.resultSetToTableModel(resultSet));
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        else if (e.getSource()==print)
        {
            try
            {
                table.print();

            } catch (Exception ex)
            {
                ex.printStackTrace();
            }
        }
        else
        {
            setVisible(false);
        }

    }




    public static void main(String[] args)
    {
        new Deposite_Details();

    }
}
