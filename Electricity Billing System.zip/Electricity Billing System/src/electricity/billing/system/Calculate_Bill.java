package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;

public class Calculate_Bill extends JFrame implements ActionListener
{
    Choice meternoCho,monthCho;
    JLabel nameText,addressText;
    JTextField unitconsumedText;
    JButton submit,cancel;
    Calculate_Bill()
    {
        super("Calculate Bill");

        Panel panel=new Panel();
        panel.setLayout(null);
        panel.setBackground(new Color(175, 213, 145));
        add(panel);

        JLabel heading=new JLabel("Calculate Electricity Bill");
        heading.setBounds(50,10,450,20);
        heading.setFont(new Font("Tahoma",Font.BOLD,20));
        panel.add(heading);

        JLabel meterno=new JLabel("Meter Number");
        meterno.setBounds(50,80,100,30);
        panel.add(meterno);
        meternoCho=new Choice();
        try
        {
            Database c=new Database();
            ResultSet resultSet=c.statement.executeQuery("select * from new_customer");
            while (resultSet.next())
            {
                meternoCho.add(resultSet.getString("meter_no"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        meternoCho.setBounds(180,80,150,30);
        panel.add(meternoCho);

        JLabel name=new JLabel("Name");
        name.setBounds(50,120,100,30);
        panel.add(name);
        nameText=new JLabel("");
        nameText.setBounds(180,120,150,30);
        panel.add(nameText);

        JLabel address=new JLabel("Address");
        address.setBounds(50,160,100,30);
        panel.add(address);
        addressText=new JLabel("");
        addressText.setBounds(180,160,150,30);
        panel.add(addressText);

        try
        {
            Database c=new Database();
            ResultSet resultSet=c.statement.executeQuery("select * from new_customer where meter_no='"+meternoCho.getSelectedItem()+"'");
            while (resultSet.next())
            {
                nameText.setText(resultSet.getString("name"));
                addressText.setText(resultSet.getString("address"));

            }
        }catch (Exception E)
        {
            E.printStackTrace();
        }

        meternoCho.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                try
                {
                    Database c=new Database();
                    ResultSet resultSet=c.statement.executeQuery("select * from new_customer where meter_no='"+meternoCho.getSelectedItem()+"'");
                    while (resultSet.next())
                    {
                        nameText.setText(resultSet.getString("name"));
                        addressText.setText(resultSet.getString("address"));

                    }
                }catch (Exception E)
                {
                    E.printStackTrace();
                }
            }
        });

        JLabel unitconsumed=new JLabel("Unit Consumed");
        unitconsumed.setBounds(50,200,100,30);
        panel.add(unitconsumed);
        unitconsumedText=new JTextField();
        unitconsumedText.setBounds(180,200,150,30);
        panel.add(unitconsumedText);

        JLabel month=new JLabel("Month");
        month.setBounds(50,240,100,30);
        panel.add(month);
        monthCho=new Choice();
        monthCho.add("January");
        monthCho.add("February");
        monthCho.add("March");
        monthCho.add("April");
        monthCho.add("May");
        monthCho.add("June");
        monthCho.add("July");
        monthCho.add("August");
        monthCho.add("September");
        monthCho.add("October");
        monthCho.add("November");
        monthCho.add("December");
        monthCho.setBounds(180,240,150,30);
        panel.add(monthCho);

        submit=new JButton("Submit");
        submit.setBounds(50,300,125,30);
        submit.setBackground(new Color(46, 92, 161));
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        panel.add(submit);

        cancel=new JButton("Cancel");
        cancel.setBounds(200,300,125,30);
        cancel.setBackground(new Color(46, 92, 161));
        cancel.setForeground(Color.WHITE);
        submit.addActionListener(this);
        panel.add(cancel);

        setLayout(new BorderLayout());
        add(panel,"Center");

        ImageIcon II1=new ImageIcon(ClassLoader.getSystemResource("Icon/calculate_page.jpg"));
        Image II2=II1.getImage().getScaledInstance(230,320,Image.SCALE_DEFAULT);
        ImageIcon II3=new ImageIcon(II2);
        JLabel II4=new JLabel(II3);
        add(II4,"East");






        setSize(650,450);
        setLocation(400,150);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==submit)
        {
            String smeterNo=meternoCho.getSelectedItem();
            String sunit=unitconsumedText.getText();
            String smonth=monthCho.getSelectedItem();

            int totalbill=0;
            int units=Integer.parseInt(sunit);
            String query_tax="select * from tax";

            try
            {
                Database c=new Database();
                ResultSet resultSet=c.statement.executeQuery(query_tax);
                while (resultSet.next())
                {
                    totalbill += units * Integer.parseInt(resultSet.getString("cost_per_unit"));
                    totalbill += Integer.parseInt(resultSet.getString("meter_rent"));
                    totalbill += Integer.parseInt(resultSet.getString("service_charge"));
                    totalbill += Integer.parseInt(resultSet.getString("swacch_bharat"));
                    totalbill += Integer.parseInt(resultSet.getString("fixed_tax"));


                }
            }
            catch (Exception E)
            {
                E.printStackTrace();
            }
            String query_total_bill="insert into bill values('"+smeterNo+"','"+smonth+"','"+sunit+"','"+totalbill+"','Not Paid')";
            try
            {
                Database c=new Database();
                c.statement.executeUpdate(query_total_bill);

                JOptionPane.showMessageDialog(null,"Customer Bill Updated Successfully");
                setVisible(false);
            }
            catch (Exception E)
            {
                E.printStackTrace();
            }
        }
        else
        {
            setVisible(false);
        }

    }

    public static void main(String[] args)
    {

        new Calculate_Bill();

    }
}
