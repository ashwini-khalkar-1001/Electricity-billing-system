package electricity.billing.system;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Payment_Bill extends JFrame implements ActionListener
{
    JButton back;
    String meter;
    Payment_Bill( String meter)
    {
        super("Bill Payment");

        this.meter=meter;
        JEditorPane j=new JEditorPane();
        j.setEditable(false);

        try
        {

            j.setPage("https://payments.google.com/gp/w/u/0/home/signup");
            j.setBounds(10,100,750,500);
        } catch (Exception e) {
            e.printStackTrace();
            j.setContentType("text/html");
            j.setText("<html> Error! Error! Error! Error! Error!</html>");
        }

       JScrollPane pane=new JScrollPane(j);
        pane.setBounds(30,80,730,450);
       add(pane);


        back=new JButton("Back");
        back.setBounds(640,20,80,30);
        back.addActionListener(this);
        add(back);



        setSize(800,600);
        setLocation(300,100);
        setLayout(null);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {

        setVisible(false);
        new Pay_Bill(meter);
    }

    public static void main(String[] args)
    {
        new Payment_Bill("");
    }
}
