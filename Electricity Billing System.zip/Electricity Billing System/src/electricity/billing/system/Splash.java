package electricity.billing.system;

import javax.swing.*;
import java.awt.*;

public class Splash extends JFrame
{
    Splash()
    {
        super("splash");
        ImageIcon imageIcon=new ImageIcon(ClassLoader.getSystemResource("Icon/splashone.jpg"));
        Image imageone=imageIcon.getImage().getScaledInstance(600,400,Image.SCALE_DEFAULT);
        ImageIcon imageIcon2=new ImageIcon(imageone);
        JLabel imgLabel=new JLabel(imageIcon2);
        add(imgLabel);
        //JLabel name=new JLabel("Electricity billing system");
        //name.setBounds(100,100,200,40);
        //add(name);


        setSize(600,400);
        setLocation(100,100);
        setVisible(true);

        try
        {
            Thread.sleep(2000);
            setVisible(false);
            new Login();

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e);
        }
    }
    public static void main(String[] args)
    {
        Splash sp=new Splash();


    }
}
