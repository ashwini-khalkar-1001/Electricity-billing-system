package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MeterInfo extends JFrame implements ActionListener
{
    Choice meterlocCho,metertypeCho,phasecodeCho,billtypeCho;
    JButton submit;
    String meterNumber;
    MeterInfo(String meterNumber)
    {

        super("Meter Information");
        this.meterNumber=meterNumber;
        JPanel panel=new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(194, 163, 220));
        add(panel);


        JLabel heading=new JLabel("Meter Information");
        heading.setBounds(190,10,200,30);
        heading.setFont(new Font("Tahone",Font.BOLD,20));
        panel.add(heading);


        JLabel meternumber=new JLabel("Meter Number");
        meternumber.setBounds(50,80,100,30);
        panel.add(meternumber);
        JLabel meternumberText=new JLabel(meterNumber);
        meternumberText.setBounds(180,80,150,30);
        panel.add(meternumberText);

        JLabel meterloc=new JLabel("Meter Location");
        meterloc.setBounds(50,120,100,30);
        panel.add(meterloc);
        meterlocCho=new Choice();
        meterlocCho.add("Outside");
        meterlocCho.add("Inside");
        meterlocCho.setBounds(180,120,150,30);
        panel.add(meterlocCho);

        JLabel metertype=new JLabel("Meter Type");
        metertype.setBounds(50,160,100,30);
        panel.add(metertype);
        metertypeCho=new Choice();
        metertypeCho.add("Electric Meter");
        metertypeCho.add("Solar Meter");
        metertypeCho.add("Smart Meter");
        metertypeCho.setBounds(180,160,150,30);
        panel.add(metertypeCho);

        JLabel phasecode=new JLabel("Phase Code ");
        phasecode.setBounds(50,200,100,30);
        panel.add(phasecode);
        phasecodeCho=new Choice();
        phasecodeCho.add("011");
        phasecodeCho.add("022");
        phasecodeCho.add("033");
        phasecodeCho.add("044");
        phasecodeCho.add("055");
        phasecodeCho.add("066");
        phasecodeCho.add("077");
        phasecodeCho.add("088");
        phasecodeCho.add("099");
        phasecodeCho.setBounds(180,200,150,30);
        panel.add(phasecodeCho);

        JLabel billtype=new JLabel("Bill Type");
        billtype.setBounds(50,240,100,30);
        panel.add(billtype);
        billtypeCho=new Choice();
        billtypeCho.add("Normal");
        billtypeCho.add("Industrial");
        billtypeCho.setBounds(180,240,150,30);
        panel.add(billtypeCho);

        JLabel days=new JLabel("30 Days billing time...");
        days.setBounds(50,290,150,30);
        panel.add(days);

        JLabel note=new JLabel("Note:-");
        note.setBounds(50,320,100,30);
        panel.add(note);

        JLabel note1=new JLabel("By default bill is calculated for 30 days only");
        note1.setBounds(50,350,300,30);
        panel.add(note1);

        submit=new JButton("Submit");
        submit.setBounds(200,400,125,30);
        submit.setBackground(new Color(46, 92, 161));
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        panel.add(submit);

        setLayout(new BorderLayout());
        add(panel,"Center");

        ImageIcon I11=new ImageIcon(ClassLoader.getSystemResource("Icon/meterinfo.jpg"));
        Image I22=I11.getImage().getScaledInstance(250,320,Image.SCALE_DEFAULT);
        ImageIcon I33=new ImageIcon(I22);
        JLabel I44=new JLabel(I33);
        add(I44,"East");


        setSize(750,550);
        setLocation(300,100);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==submit)
        {
            String smeterno=meterNumber;
            String smeterloc=meterlocCho.getSelectedItem();
            String smetertyp=metertypeCho.getSelectedItem();
            String sphasecode=phasecodeCho.getSelectedItem();
            String sbilltype=billtypeCho.getSelectedItem();
            String sday="30";

            String query_meterinfo="insert into meter_info values('"+smeterno+"','"+smeterloc+"','"+smetertyp+"','"+sphasecode+"','"+sbilltype+"','"+sday+"')";

            try
            {
                Database c=new Database();
                c.statement.executeUpdate(query_meterinfo);

                JOptionPane.showMessageDialog(null,"Meter Information Submited Successfully");
                setVisible(false);

            }
            catch (Exception E)
            {
                E.printStackTrace();
            }
        }else
        {
            setVisible(false);
        }

    }

    public static void main(String[] args)
    {
        new MeterInfo("");
    }
}
