const counters = document.querySelectorAll(".counter");
let started = false;

function animateCounters() {
  if (started) return;

  const section = document.getElementById("counter");
  const sectionTop = section.getBoundingClientRect().top;

  if (sectionTop < window.innerHeight) {
    started = true;
    counters.forEach(counter => {
      const target = +counter.getAttribute("data-target");
      const speed = 200; // lower = faster

      const updateCount = () => {
        const current = +counter.innerText.replace(/k/, '');
        const increment = Math.ceil(target / speed);

        if (current < target) {
          counter.innerText = Math.ceil(current + increment);
          setTimeout(updateCount, 10);
        } else {
          const display = target >= 1000 ? (target / 1000).toFixed(1) + "k" : target;
          counter.innerText = display;
        }
      };

      updateCount();
    });
  }
}

window.addEventListener("scroll", animateCounters);