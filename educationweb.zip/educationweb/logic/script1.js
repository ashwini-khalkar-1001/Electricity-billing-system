// Animate cards on scroll
const cards = document.querySelectorAll('.fade-in');

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target); // Run once
    }
  });
}, {
  threshold: 0.2
});

cards.forEach(card => observer.observe(card));