const slider = document.getElementById('blogSlider');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');

const scrollAmount = 400; // pixels to scroll

nextBtn.addEventListener('click', () => {
  slider.scrollBy({ left: scrollAmount, behavior: 'smooth' });
});

prevBtn.addEventListener('click', () => {
  slider.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
});